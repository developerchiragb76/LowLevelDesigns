package org.example.ride.sharing.application.model;

public enum RidePreference {
    EARLIEST_ENDING,
    LOWEST_DURATION,
    PREFERRED_VEHICLE,
    MOST_VACANT
}
