package org.example.ride.sharing.application.model;

public enum Gender {
    M,
    F
}
