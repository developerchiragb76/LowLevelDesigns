package org.example.ride.sharing.application.exception;

public class RideValidationCriteriaNotMetException extends Throwable {
}
