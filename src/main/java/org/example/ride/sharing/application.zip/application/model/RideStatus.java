package org.example.ride.sharing.application.model;

public enum RideStatus {
    SCHEDULED,
    ONGOING,
    COMPLETED,
    CANCELLED
}
