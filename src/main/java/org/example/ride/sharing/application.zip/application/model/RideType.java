package org.example.ride.sharing.application.model;

public enum RideType {
    OFFERED,
    TAKEN
}
