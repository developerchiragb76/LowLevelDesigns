package org.example.ride.sharing.application.model;

public enum VehicleType {
    SWIFT,
    ACTIVA,
    POLO
}
