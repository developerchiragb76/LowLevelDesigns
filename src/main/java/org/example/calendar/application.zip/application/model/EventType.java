package org.example.calendar.application.model;

public enum EventType {
    MEETINGS,
    HOLIDAYS,
    BIRTHDAYS,
    REMINDERS
}
