package org.example.calendar.application.model;

public interface ILocationTypeData {
}
