package org.example.calendar.application.model;

public class BirthdayEventTypeData implements IEventData {

}
