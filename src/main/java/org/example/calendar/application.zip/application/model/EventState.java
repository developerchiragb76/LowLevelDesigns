package org.example.calendar.application.model;

public enum EventState {
    NEUTRAL,
    ACCEPTED,
    REJECTED
}
