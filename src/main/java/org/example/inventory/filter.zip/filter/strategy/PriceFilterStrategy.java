package org.example.inventory.filter.strategy;

import org.example.inventory.filter.model.IFilterTypeData;
import org.example.inventory.filter.model.PriceFilterTypeData;
import org.example.inventory.filter.model.Product;

import java.util.Map;

public class PriceFilterStrategy implements IFilterStrategy<PriceFilterTypeData>{
    @Override
    public boolean doesSupport(String key) {
        return "price".equals(key);
    }

    @Override
    public boolean doesMatch(IFilterTypeData filterTypeData, Product product) {
        Double ltprice = (double) 0;
        Double gtPrice = (double) 0;
        PriceFilterTypeData priceFilterTypeData = (PriceFilterTypeData) filterTypeData;
        Map<String, Object> priceMap = priceFilterTypeData.getPriceMap();
        for(String priceKey : priceMap.keySet()) {
            if(priceKey.equals("lt")){
                ltprice = (double) priceMap.get(priceKey);
            }

            if(priceKey.equals("gt")) {
                gtPrice = (double) priceMap.get(priceKey);
            }
        }

        if(ltprice > 0 && gtPrice > 0) {
            return product.getPrice() > gtPrice && product.getPrice() < ltprice;
        } else if(ltprice > 0) {
            return product.getPrice() < ltprice;
        } else if(gtPrice > 0) {
            return product.getPrice() > gtPrice;
        }

        return false;
    }
}
