Inventory Filter
-> You have a list of products with you and you want to support filter on top of it.
-> List of Products: [
    {
        "id": "iphone_15",
        "name" : "Iphone 15",
        "price" : 1234,
        "category": "phone"
    },
    {   
        "id": "iphone_16",
        "name" : "Iphone 16",
        "price" : 1342,
        "category" : "phone"
    },
    {
        "id' : "sony_bravia_43",
        "name" : "Sony Bravia 43",
        "price" : 564,
        "category" : "tv"
    },
    {
        "id' : "sony_bravia_55",
        "name" : "Sony Bravia 55",
        "price" : 964,
        "category" : "tv"
    },
]