package org.example.inventory.filter.model;

public interface IFilterTypeData {
}
