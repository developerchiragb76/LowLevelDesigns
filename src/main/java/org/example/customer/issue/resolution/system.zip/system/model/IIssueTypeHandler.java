package org.example.customer.issue.resolution.system.model;

public interface IIssueTypeHandler {
    boolean doesHandle(IssueType issueType);
}
