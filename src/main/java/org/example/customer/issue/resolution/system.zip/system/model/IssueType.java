package org.example.customer.issue.resolution.system.model;

public enum IssueType {
    MUTUAL_FUND,
    PAYMENT,
    INTERNAL,
    GOLD,
    INSURANCE
}
