package org.example.customer.issue.resolution.system.model;

public enum IssueState {
    IN_PROGRESS,
    RESOLVED
}
