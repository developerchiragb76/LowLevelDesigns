package org.example.food.ordering.system.model;


import java.util.List;

public class Menu {
    private String restaurantId;
    private List<MenuItem> menuItemList;
}
