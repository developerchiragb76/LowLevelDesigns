package org.example.food.ordering.system.model;

public class MenuItem {
    private String itemName;
    private Quantity itemQuantity;
    private Price itemPrice;
}
