package org.example.food.ordering.system.model;

public enum Currency {
    INR,
    USD
}
