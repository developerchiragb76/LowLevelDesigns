package org.example.food.ordering.system.model;

public enum OrderStatus {
    ACCEPTED,
    COMPLETED
}
