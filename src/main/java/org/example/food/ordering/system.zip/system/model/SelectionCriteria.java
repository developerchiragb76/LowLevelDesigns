package org.example.food.ordering.system.model;

public enum SelectionCriteria {
    LOWEST_COST,
    BEST_RATING
}
