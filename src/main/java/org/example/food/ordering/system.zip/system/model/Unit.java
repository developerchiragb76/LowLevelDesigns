package org.example.food.ordering.system.model;

public enum Unit {
    KG,
    G
}
