package org.example.food.ordering.system.model;

public class OrderInputItem {
    private String itemName;
    private int itemQuantity;
}
