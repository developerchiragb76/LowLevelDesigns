package org.example.food.ordering.system.model;

public class Quantity {
    private double itemPrice;
    private Unit itemUnit;
}
