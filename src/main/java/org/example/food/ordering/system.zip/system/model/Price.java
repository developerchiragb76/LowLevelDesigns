package org.example.food.ordering.system.model;

public class Price {
    private double itemPrice;
    private Currency itemCurrency;
}
