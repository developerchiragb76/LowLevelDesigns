package org.example.food.ordering.system.model;

public class User {
    private String userId;

    public String getUserId() {
        return userId;
    }
}
